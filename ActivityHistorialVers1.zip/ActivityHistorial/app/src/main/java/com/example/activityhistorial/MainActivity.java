package com.example.activityhistorial;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listaSubjects;
    ArrayAdapter<String> adaptador;
    ArrayList<String> elementos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaSubjects = findViewById(R.id.vistaList);
        elementos = new ArrayList<>();

        // Agregar elementos a la lista
        elementos.add("Subject 1");
        elementos.add("Subject 2");
        elementos.add("Subject 3");

        adaptador = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, elementos);
        listaSubjects.setAdapter(adaptador);

        listaSubjects.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = elementos.get(position); // Obtener el elemento seleccionado
                Intent intent = new Intent(MainActivity.this, DescActivityHistorial.class);
                intent.putExtra("selectedItem", selectedItem); // Pasar el valor seleccionado al segundo Activity
                startActivity(intent); // Abrir el segundo Activity
            }
        });


        FloatingActionButton fabDialog = findViewById(R.id.fab);
        fabDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDel = new AlertDialog.Builder(MainActivity.this);
                alertDel.setMessage("¿Seguro que desea borrar todo el historial?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Implementación de borrar el registro
                                elementos.clear();
                                adaptador.notifyDataSetChanged();

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });
                AlertDialog titulo = alertDel.create();
                titulo.setTitle("Eliminación de todos los registros");
                titulo.show();

                Window window = titulo.getWindow();
                if (window != null) {
                    // Cambiar el color de fondo
                    window.setBackgroundDrawableResource(R.color.red);
                }

            }
        });
    }
}